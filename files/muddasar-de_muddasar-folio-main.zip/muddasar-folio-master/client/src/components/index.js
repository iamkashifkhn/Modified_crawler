export { default as Navbar } from "./Navbar/Navbar";
export { default as NavigationDots } from "./NavigationDots/NavigationDots";
export { default as SocialMedia } from "./SocialMedia/SocialMedia";

import React from "react";

const Skills = () => {
  return <div id="skills">Skills</div>;
};

export default Skills;

import React from "react";

const Testinmonials = () => {
  return <div>Testinmonials</div>;
};

export default Testinmonials;
